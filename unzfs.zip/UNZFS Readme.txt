----------------------------
UNZFS extracter/uncompressor
----------------------------

Name:		UNZFS 0.1a
Type:		Editing tool
Author:		Blake "Dummy" Robinson,
Created:	27th June 2003
Tools used:	MSVC++ 6
Target game:	Battlezone

Description:
UNZFS allows you to extract and uncompress Activision ZFS
files used by Battlezone (and probably other Activision
titles that use it). Now I know you're probably thinking
'Hey wait up, theres already an UNZFS extractor'. This one
is different as if also uncompresses the files inside the
archive. This means that you can finally unlock all those
files you wanted to edit in Battlezone but never could.

This program is a console application. To use it click the
start menu, select Run and type CMD. Then type

CD c:\program files\activision\battlezone\

(or wherever your Battlezone is installed) and type

unzfs /? 

for a list of commands that the program uses.
-----------------------------------------------------------


Installation:
Extract and run UNZFS.exe from the ZIP archive
-----------------------------------------------------------


Uninstallation:
If you wish to remove this plugin you can simply delete the 
following file(s):

UNZFS.exe

-----------------------------------------------------------


Distribution:

These files may only be redistributed if this readme is included.

-----------------------------------------------------------


Thanks:

Thanks to the team that bought us Battlezone, the only RTS I 
ever enjoyed playing.

-----------------------------------------------------------

UNZFS extractor/uncompressor by Dummy. (c) 2003 Paradum Games
http://games.paradum.com