The files in this directory should be placed in the addon directory within the main Nitro Pack directory.

Placing a file in the addon directory overrides the file of the same name in the nitro.zfs file.

----------------------------------------------------------------

UH-1B Huey Helicopter

vuchuey3.vcf is a VCF (the "Huey gunship" variant) extracted from nitro.zfs and modified such that all armor and chassis values are 65,535 (increased from 1000 and 600 respectively in the original).

----------------------------------------------------------------

AH-1 Cobra Helicopter

vugcobr1.vcf and vugcobr2.vcf are VCFs extracted from nitro.zfs and modified such that all armor and chassis values are 65,535 (increased from 800 in the originals).
